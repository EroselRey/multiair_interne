<?php
// MULTIAIR — API JSON (appelée par Make et par la page)
// Routes : api.php?r=<ressource>[/<id>[/<action>]]   Méthodes : GET, POST, PATCH, DELETE
// Auth   : header X-Api-Key (Make) ou session (page)
declare(strict_types=1);
require __DIR__ . '/lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$cfg = ma_config();
$method = $_SERVER['REQUEST_METHOD'];
$route = trim((string) ($_GET['r'] ?? ''), '/');
$parts = $route === '' ? [] : explode('/', $route);

// Corps JSON (Make envoie du JSON ; on accepte aussi du form-urlencoded)
$raw = file_get_contents('php://input');
$body = [];
if ($raw !== '' && $raw !== false) {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
    } else {
        parse_str($raw, $body);
    }
}
if ($method === 'POST' && empty($body) && !empty($_POST)) {
    $body = $_POST;
}
// Surcharge de méthode (Make ne sait pas toujours faire PATCH/DELETE)
if (!empty($body['_method'])) {
    $method = strtoupper((string) $body['_method']);
} elseif (!empty($_GET['_method'])) {
    $method = strtoupper((string) $_GET['_method']);
}

function out($data, int $code = 200): never
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function fail(string $msg, int $code = 400): never
{
    out(['ok' => false, 'erreur' => $msg], $code);
}

// ------------------------------------------------------------------ Authentification
$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? ($_GET['key'] ?? ($body['api_key'] ?? null));
$viaApiKey = is_string($apiKey) && $apiKey !== '' && hash_equals((string) $cfg['api_key'], $apiKey);
$viaSession = ma_is_logged();

if ($parts === ['auth', 'login'] && $method === 'POST') {
    $u = ma_verifier_connexion(ma_db(), (string) ($body['login'] ?? ''), (string) ($body['password'] ?? ''));
    if ($u) {
        ma_ouvrir_session($u);
        out(['ok' => true, 'utilisateur' => $u]);
    }
    usleep(500000);
    fail('E-mail ou mot de passe incorrect', 401);
}
if ($parts === ['auth', 'logout']) {
    ma_session_start();
    $_SESSION = [];
    session_destroy();
    out(['ok' => true]);
}
if ($parts === ['auth', 'recover'] && $method === 'POST') {
    // Mot de passe oublié : un lien part à l'adresse du compte, s'il existe. La réponse est la même
    // dans tous les cas, pour ne pas révéler qui a un compte.
    $email = trim((string) ($body['email'] ?? ''));
    if (str_contains($email, '@')) {
        $st = ma_db()->prepare("SELECT * FROM rep_contacts WHERE lower(email) = lower(?) AND actif = 1 AND acces IN ('admin','sav','commerce','finance') LIMIT 1");
        $st->execute([$email]);
        if ($c = $st->fetch()) {
            ma_compte_lien(ma_db(), $c, 'reinit');
        }
    }
    out(['ok' => true, 'message' => 'Si un compte existe pour cette adresse, un lien pour choisir un nouveau mot de passe vient d\'y être envoyé.']);
}
if ($parts === ['auth', 'me']) {
    out(['ok' => true, 'connecte' => $viaSession, 'utilisateur' => ma_user()]);
}
if ($parts === ['ping']) {
    out(['ok' => true, 'version' => MA_VERSION, 'auth' => $viaApiKey ? 'api_key' : ($viaSession ? 'session' : 'aucune'), 'date' => ma_now()]);
}

if (!$viaApiKey && !$viaSession) {
    fail('Non autorisé (clé API ou session requise)', 401);
}

$db = ma_db();
$now = ma_now();

// ------------------------------------------------------------------ Droits
// Make (clé API) et les administrateurs : tout. Un service (sav, commerce, finance) : les demandes
// de son service, leur suivi, les conversations qui s'y rattachent, et les noms de l'équipe.
$user = $viaApiKey ? null : ma_user();
$estAdmin = $viaApiKey || (($user['acces'] ?? '') === 'admin');
$portee = $estAdmin ? null : ma_acces_service_demande((string) ($user['acces'] ?? ''));
if (!$estAdmin) {
    $r0 = $parts[0] ?? '';
    $r1 = $parts[1] ?? null;
    $lecture = $method === 'GET';
    $permis = $portee !== null && (
        ($r0 === 'rep' && $r1 === 'demandes' && ($lecture || (($method === 'PATCH' || $method === 'POST') && isset($parts[2]))))
        || ($r0 === 'rep' && in_array($r1, ['fiches', 'messages', 'listes'], true) && $lecture)
        || ($r0 === 'equipe' && $lecture && !isset($parts[1]))
        || ($r0 === 'clients' && ($lecture || (($parts[2] ?? null) === 'equipements'))));
    if (!$permis) {
        fail('Accès réservé aux administrateurs', 403);
    }
}
$SVC_FICHE = ['SAV' => 'technique', 'COMMERCIAL' => 'commercial', 'FINANCE' => 'finance'];

// ------------------------------------------------------------------ Helpers SQL
function cols(PDO $db, string $table): array
{
    static $cache = [];
    if (!isset($cache[$table])) {
        $cache[$table] = array_column($db->query("PRAGMA table_info($table)")->fetchAll(), 'name');
    }
    return $cache[$table];
}

/** Ne garde que les colonnes existantes (hors id). */
function pick(PDO $db, string $table, array $data): array
{
    $allowed = array_diff(cols($db, $table), ['id']);
    $out = [];
    foreach ($allowed as $c) {
        if (array_key_exists($c, $data)) {
            $out[$c] = $data[$c];
        }
    }
    return $out;
}

function insert(PDO $db, string $table, array $data): int
{
    $data = pick($db, $table, $data);
    if (!$data) {
        fail("Aucune donnée exploitable pour $table");
    }
    $keys = array_keys($data);
    $sql = "INSERT INTO $table (" . implode(',', $keys) . ') VALUES (' . implode(',', array_fill(0, count($keys), '?')) . ')';
    $db->prepare($sql)->execute(array_values($data));
    return (int) $db->lastInsertId();
}

function update(PDO $db, string $table, int $id, array $data): void
{
    $data = pick($db, $table, $data);
    if (!$data) {
        return;
    }
    $set = implode(',', array_map(fn($k) => "$k = ?", array_keys($data)));
    $vals = array_values($data);
    $vals[] = $id;
    $db->prepare("UPDATE $table SET $set WHERE id = ?")->execute($vals);
}

function getOne(PDO $db, string $table, int $id): ?array
{
    $st = $db->prepare("SELECT * FROM $table WHERE id = ?");
    $st->execute([$id]);
    $r = $st->fetch();
    return $r ?: null;
}

/**
 * Liste générique avec filtres simples :
 *   ?q=texte (recherche sur les colonnes texte), ?statut=a,b, ?from=YYYY-MM-DD, ?to=YYYY-MM-DD,
 *   ?limit=, ?offset=, ?order=col, ?dir=asc|desc, plus ?<colonne>=valeur pour une égalité.
 */
function listRows(PDO $db, string $table, string $dateCol, array $q, array $textCols = []): array
{
    // Garde-fou : une écriture qui arrive jusqu'ici n'a été traitée par aucune route.
    // Sans cela, un POST recevrait la liste des lignes avec « ok », et le scénario Make
    // croirait avoir enregistré (c'est ce qui est arrivé aux devis CSO le 14/09).
    $methode = (string) ($GLOBALS['method'] ?? 'GET');
    if ($methode !== 'GET') {
        $scenario = explode('_', $table)[0];
        $scenario = ['rep' => 'repondeur', 'chat' => 'chatbot'][$scenario] ?? $scenario;
        logEvent($db, $scenario, 'erreur', 'requete_non_traitee',
            "$methode sur « $table » : aucune route d'écriture ne correspond, rien n'a été enregistré",
            ['route' => $_GET['r'] ?? null]);
        fail("Requête $methode non reconnue pour $table : rien n'a été enregistré", 400);
    }
    $where = [];
    $args = [];
    $allCols = cols($db, $table);
    if (!empty($q['statut'])) {
        $vals = array_map('trim', explode(',', (string) $q['statut']));
        $where[] = 'statut IN (' . implode(',', array_fill(0, count($vals), '?')) . ')';
        array_push($args, ...$vals);
    }
    if (!empty($q['from'])) {
        $where[] = "$dateCol >= ?";
        $args[] = ma_date((string) $q['from']);
    }
    if (!empty($q['to'])) {
        $where[] = "$dateCol <= ?";
        $args[] = ma_date((string) $q['to'] . ' 23:59:59');
    }
    if (!empty($q['q']) && $textCols) {
        $like = [];
        foreach ($textCols as $c) {
            $like[] = "$c LIKE ?";
            $args[] = '%' . $q['q'] . '%';
        }
        $where[] = '(' . implode(' OR ', $like) . ')';
    }
    foreach ($q as $k => $v) {
        if (in_array($k, ['r', 'key', 'q', 'statut', 'from', 'to', 'limit', 'offset', 'order', 'dir', '_method'], true)) {
            continue;
        }
        if (in_array($k, $allCols, true) && $v !== '') {
            $where[] = "$k = ?";
            $args[] = $v;
        }
    }
    $order = (!empty($q['order']) && in_array($q['order'], $allCols, true)) ? $q['order'] : $dateCol;
    $dir = (isset($q['dir']) && strtolower((string) $q['dir']) === 'asc') ? 'ASC' : 'DESC';
    $limit = max(1, min(5000, (int) ($q['limit'] ?? 2000)));
    $offset = max(0, (int) ($q['offset'] ?? 0));
    $sql = "SELECT * FROM $table" . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
        . " ORDER BY $order $dir, id $dir LIMIT $limit OFFSET $offset";
    $st = $db->prepare($sql);
    $st->execute($args);
    return $st->fetchAll();
}

function logEvent(PDO $db, string $scenario, string $statut, string $type, ?string $resume, $payload = null): void
{
    $db->prepare('INSERT INTO executions_log(scenario, date, statut, type_evenement, resume, payload) VALUES (?,?,?,?,?,?)')
        ->execute([$scenario, ma_now(), $statut, $type, $resume, is_null($payload) ? null : json_encode($payload, JSON_UNESCAPED_UNICODE)]);
}

function idFrom(array $parts, int $i): int
{
    $id = (int) ($parts[$i] ?? 0);
    if ($id <= 0) {
        fail('Identifiant manquant');
    }
    return $id;
}

function param(array $body, array $get, string $key, $default = null)
{
    return $body[$key] ?? ($get[$key] ?? $default);
}

/** Routes de routage communes : find / liste / création / suppression. */
function routageRoutes(PDO $db, string $scenario, ?string $sub2, string $method, array $body): never
{
    if ($sub2 === 'find' || isset($_GET['cle'])) {
        out(['ok' => true] + ma_routage($db, $scenario, (string) ($_GET['cle'] ?? '')));
    }
    if ($method === 'POST' || $method === 'PATCH') {
        $cle = trim((string) ($body['cle'] ?? ''));
        if ($cle === '') {
            fail('cle requise');
        }
        if ($scenario === 'chatbot') {
            $cle = strtolower($cle);
        }
        $db->prepare('INSERT OR REPLACE INTO routage(scenario, cle, dest_to, dest_cc, libelle) VALUES (?,?,?,?,?)')
            ->execute([$scenario, $cle, ma_str($body['dest_to'] ?? null), ma_str($body['dest_cc'] ?? null) ?? '', ma_str($body['libelle'] ?? null)]);
    }
    if ($method === 'DELETE') {
        $db->prepare('DELETE FROM routage WHERE scenario = ? AND cle = ?')->execute([$scenario, trim((string) ($body['cle'] ?? $sub2 ?? ''))]);
    }
    $st = $db->prepare('SELECT * FROM routage WHERE scenario = ? ORDER BY cle');
    $st->execute([$scenario]);
    out(['ok' => true, 'scenario' => $scenario, 'rows' => $st->fetchAll()]);
}

$res = $parts[0] ?? '';
$sub = $parts[1] ?? null;
$sub2 = $parts[2] ?? null;

try {
    switch ($res) {

        // ============================================================ Journal & paramètres
        case 'log':
            if ($method === 'POST') {
                $scenario = ma_str($body['scenario'] ?? null) ?? fail('scenario requis');
                logEvent($db, $scenario, ma_str($body['statut'] ?? null) ?? 'ok', ma_str($body['type'] ?? null) ?? 'execution',
                    ma_str($body['resume'] ?? null), $body['payload'] ?? null);
                out(['ok' => true]);
            }
            out(['ok' => true, 'rows' => listRows($db, 'executions_log', 'date', $_GET, ['resume', 'type_evenement'])]);

        case 'parametres':
            if ($method === 'POST' || $method === 'PATCH') {
                foreach ((array) ($body['valeurs'] ?? $body) as $k => $v) {
                    if (preg_match('/^[a-z0-9_]+$/', (string) $k)) {
                        $db->prepare('INSERT OR REPLACE INTO parametres(cle, valeur) VALUES (?,?)')->execute([$k, ma_str($v)]);
                    }
                }
            }
            out(['ok' => true, 'parametres' => $db->query('SELECT cle, valeur FROM parametres')->fetchAll(PDO::FETCH_KEY_PAIR)]);

        // ============================================================ Répondeur IA
        case 'rep':
            if ($sub === 'fiches') {
                if ($sub2 === 'find') {
                    // Remplace filterRows QUALIFICATION_EN_COURS : ?tel=…&statut=En attente,Urgent
                    $tel = ma_tel((string) ($_GET['tel'] ?? ''));
                    $where = ['1=1'];
                    $args = [];
                    if ($tel) {
                        $where[] = 'tel_norm = ?';
                        $args[] = $tel;
                    }
                    if (!empty($_GET['statut'])) {
                        $vals = array_map('trim', explode(',', (string) $_GET['statut']));
                        $where[] = 'statut IN (' . implode(',', array_fill(0, count($vals), '?')) . ')';
                        array_push($args, ...$vals);
                    }
                    if (!empty($_GET['older_than_min'])) {
                        $where[] = "created_at <= ?";
                        $args[] = date('Y-m-d H:i:s', time() - 60 * (int) $_GET['older_than_min']);
                    }
                    $dir = (($_GET['dir'] ?? 'desc') === 'asc') ? 'ASC' : 'DESC';
                    $limit = max(1, min(100, (int) ($_GET['limit'] ?? 1)));
                    $st = $db->prepare('SELECT * FROM rep_fiches WHERE ' . implode(' AND ', $where) . " ORDER BY created_at $dir, id $dir LIMIT $limit");
                    $st->execute($args);
                    $rows = $st->fetchAll();
                    out(['ok' => true, 'trouve' => count($rows) > 0, 'fiche' => $rows[0] ?? null, 'fiches' => $rows, 'nb' => count($rows)]);
                }
                if ($method === 'POST' && $sub2 === null) {
                    $d = $body;
                    $d['tel_norm'] = ma_tel((string) ($d['telephone'] ?? $d['tel'] ?? $d['tel_norm'] ?? ''));
                    $d['societe'] = ma_str($d['societe'] ?? $d['distributeur'] ?? null);
                    $d['service'] = strtolower(ma_str($d['service'] ?? null) ?? '');
                    // Urgence réservée au SAV (panne, production arrêtée).
                    $d['urgence'] = ma_rep_service($d['service']) === 'sav' && ma_bool($d['urgence'] ?? false) ? 1 : 0;
                    $d['statut'] = ma_str($d['statut'] ?? null) ?? ($d['urgence'] ? 'Urgent' : 'En attente');
                    if (!$d['urgence'] && $d['statut'] === 'Urgent') {
                        $d['statut'] = 'Transmis';
                    }
                    $d['created_at'] = ma_date($d['date'] ?? null) ?? $now;
                    foreach (['contact', 'marque', 'modele', 'numero_serie', 'type_panne', 'besoin_commercial', 'reference_facture', 'resume', 'justification_urgence', 'email', 'departement', 'canal', 'derniere_reponse_ia'] as $c) {
                        $d[$c] = ma_str($d[$c] ?? null);
                    }
                    $id = insert($db, 'rep_fiches', $d);
                    logEvent($db, 'repondeur', 'ok', 'fiche_creee', ($d['societe'] ?? '') . ' / ' . ($d['contact'] ?? '') . ' [' . $d['statut'] . ']', ['id' => $id]);
                    out(['ok' => true, 'id' => $id, 'tel_norm' => $d['tel_norm'], 'statut' => $d['statut']]);
                }
                if ($sub2 !== null) {
                    $id = idFrom($parts, 2);
                    if ($method === 'GET') {
                        $f = getOne($db, 'rep_fiches', $id) ?? fail('Fiche introuvable', 404);
                        if ($portee !== null && ma_plat($f['service'] ?? '') !== $SVC_FICHE[$portee]) {
                            fail('Accès réservé à un autre service', 403);
                        }
                        $st = $db->prepare('SELECT * FROM rep_demandes WHERE fiche_id = ? ORDER BY id');
                        $st->execute([$id]);
                        $f['demandes'] = $st->fetchAll();
                        out(['ok' => true, 'fiche' => $f]);
                    }
                    if ($method === 'PATCH' || $method === 'POST') {
                        $d = $body;
                        if (isset($d['telephone']) || isset($d['tel'])) {
                            $d['tel_norm'] = ma_tel((string) ($d['telephone'] ?? $d['tel']));
                        }
                        if (isset($d['distributeur'])) {
                            $d['societe'] = ma_str($d['distributeur']);
                        }
                        if (!empty($d['append_resume'])) {
                            $cur = getOne($db, 'rep_fiches', $id)['resume'] ?? '';
                            $d['resume'] = trim($cur . ' | ' . $d['append_resume'], ' |');
                        }
                        $d['updated_at'] = $now;
                        $newStatut = (string) ($d['statut'] ?? '');
                        if ($newStatut !== '' && (str_starts_with($newStatut, 'Trans') || $newStatut === 'Traite')) {
                            $d['transmis_at'] = $now;
                        }
                        update($db, 'rep_fiches', $id, $d);
                        out(['ok' => true, 'fiche' => getOne($db, 'rep_fiches', $id)]);
                    }
                    if ($method === 'DELETE') {
                        $db->prepare('DELETE FROM rep_fiches WHERE id = ?')->execute([$id]);
                        out(['ok' => true]);
                    }
                }
                $rows = listRows($db, 'rep_fiches', 'created_at', $_GET, ['societe', 'contact', 'tel_norm', 'resume', 'marque', 'modele']);
                if ($portee !== null) {
                    $rows = array_values(array_filter($rows, fn($f) => ma_plat($f['service'] ?? '') === $SVC_FICHE[$portee]));
                }
                out(['ok' => true, 'rows' => $rows]);
            }
            if ($sub === 'messages') {
                if ($method === 'POST') {
                    // Échange complet client <-> Claire (WhatsApp entrant + réponse envoyée)
                    $tel = ma_tel((string) ($body['telephone'] ?? $body['tel_norm'] ?? ''));
                    $ficheId = ma_int($body['fiche_id'] ?? null);
                    if (!$ficheId && $tel) {
                        $st = $db->prepare('SELECT id FROM rep_fiches WHERE tel_norm = ? ORDER BY id DESC LIMIT 1');
                        $st->execute([$tel]);
                        $ficheId = ma_int($st->fetchColumn()) ?: null;
                    }
                    $d = [
                        'date' => ma_date($body['date'] ?? null) ?? $now,
                        'fiche_id' => $ficheId,
                        'tel_norm' => $tel,
                        'canal' => ma_str($body['canal'] ?? null) ?? 'whatsapp',
                        'message' => ma_str($body['message'] ?? null),
                        'reponse' => ma_str($body['reponse'] ?? $body['reply'] ?? null),
                        'source' => ma_str($body['source'] ?? null),
                    ];
                    if ($d['message'] === null && $d['reponse'] === null) {
                        fail('message ou reponse requis');
                    }
                    $id = insert($db, 'rep_messages', $d);
                    out(['ok' => true, 'id' => $id, 'fiche_id' => $ficheId]);
                }
                // GET : la conversation d'une fiche (?fiche_id=) ou d'un numéro (?tel=)
                if ($portee !== null) {
                    $f = getOne($db, 'rep_fiches', (int) ($_GET['fiche_id'] ?? 0));
                    if (!$f || ma_plat($f['service'] ?? '') !== $SVC_FICHE[$portee]) {
                        out(['ok' => true, 'rows' => []]);
                    }
                    unset($_GET['tel']);
                }
                $where = ['1=1'];
                $args = [];
                if (!empty($_GET['fiche_id'])) {
                    $where[] = 'm.fiche_id = ?';
                    $args[] = (int) $_GET['fiche_id'];
                }
                if (!empty($_GET['tel'])) {
                    $where[] = 'm.tel_norm = ?';
                    $args[] = ma_tel((string) $_GET['tel']);
                }
                $sens = strtolower((string) ($_GET['dir'] ?? 'desc')) === 'asc' ? 'ASC' : 'DESC';
                $limite = min(2000, max(1, (int) ($_GET['limit'] ?? 500)));
                $st = $db->prepare('SELECT m.*, f.societe, f.contact, f.service, f.statut AS fiche_statut
                    FROM rep_messages m LEFT JOIN rep_fiches f ON f.id = m.fiche_id
                    WHERE ' . implode(' AND ', $where) . " ORDER BY m.date $sens, m.id $sens LIMIT $limite");
                $st->execute($args);
                out(['ok' => true, 'rows' => $st->fetchAll()]);
            }
            if ($sub === 'demandes') {
                if ($method === 'POST' && $sub2 === 'cloturer') {
                    // Clôture groupée (anciennes demandes importées, doublons) : sans prévenir les clients.
                    if (!$estAdmin) {
                        fail('Réservé aux administrateurs', 403);
                    }
                    $n = 0;
                    foreach ((array) ($body['ids'] ?? []) as $cid) {
                        $dm = getOne($db, 'rep_demandes', (int) $cid);
                        if ($dm && $dm['statut'] !== 'traite') {
                            $db->prepare("UPDATE rep_demandes SET statut = 'traite', traite_at = ?, traite_par = ? WHERE id = ?")
                                ->execute([$now, $user['nom'] ?? 'Administrateur', $dm['id']]);
                            ma_rep_evenement($db, (int) $dm['id'], 'traitee', $user['nom'] ?? null, 'plateforme', 'Clôturée (clôture groupée, client non prévenu)', []);
                            $n++;
                        }
                    }
                    logEvent($db, 'plateforme', 'ok', 'cloture_groupee', "$n demande(s) clôturée(s) sans prévenir les clients" . ($user ? ' par ' . $user['nom'] : ''));
                    out(['ok' => true, 'clotures' => $n]);
                }
                if ($method === 'POST' && $sub2 === null) {
                    $r = ma_rep_creer_demande($db, $body);
                    $rt = $r['rt'];
                    out(['ok' => true, 'id' => $r['id'], 'relance' => $r['relance'] ?? null, 'service' => $r['demande']['service'], 'priorite' => $r['demande']['priorite'], 'urgent' => $rt['urgent'],
                        'lien_interne' => $r['liens']['interne'], 'lien_client' => $r['liens']['client'],
                        // Champs historiques, lus par le scénario Make actuel : ils suivent désormais les règles.
                        'dest_to' => $rt['to'], 'dest_cc' => $rt['cc'], 'dest_libelle' => $rt['regle_libelle'],
                        'sms' => $rt['sms'], 'destinataires' => $r['demande']['destinataires'], 'notes' => $rt['notes'],
                        'objet' => $rt['objet'], 'mail_html' => $rt['mail_html'], 'sms_texte' => $rt['sms_texte']]);
                }
                if ($sub2 !== null) {
                    $id = idFrom($parts, 2);
                    $dem = getOne($db, 'rep_demandes', $id) ?? fail('Demande introuvable', 404);
                    if ($portee !== null && $dem['service'] !== $portee) {
                        fail('Cette demande relève d\'un autre service', 403);
                    }
                    if ($method === 'POST' && ($parts[3] ?? null) === 'transferer') {
                        $st = $db->prepare('SELECT * FROM rep_contacts WHERE id = ? AND actif = 1');
                        $st->execute([(int) ($body['contact_id'] ?? 0)]);
                        $cible = $st->fetch() ?: fail('Choisissez à qui transférer la demande');
                        if (!ma_liste_emails($cible['email'] ?? null)) {
                            fail($cible['nom'] . ' n\'a pas d\'adresse e-mail : complétez sa fiche dans « Équipe et accès »');
                        }
                        $apres = ma_rep_transferer($db, $dem, $cible, (string) ($user['nom'] ?? ''), trim((string) ($body['message'] ?? '')));
                        logEvent($db, 'repondeur', 'ok', 'demande_transferee', 'Demande ' . $id . ' transférée à ' . $cible['nom'] . ($user ? ' par ' . $user['nom'] : ''));
                        out(['ok' => true, 'demande' => $apres, 'visible' => $estAdmin || $apres['service'] === $portee]);
                    }
                    if ($method === 'PATCH' || $method === 'POST') {
                        $d = $body;
                        // Statut, rappel prévu, note : même logique que la page interne, client prévenu.
                        $etapes = array_intersect_key($d, array_flip(['statut', 'rappel_prevu', 'note', 'pris_par', 'traite_par']));
                        $autres = array_diff_key($d, $etapes + ['jeton_interne' => 1, 'jeton_client' => 1, 'pris_at' => 1, 'traite_at' => 1]);
                        if (!$estAdmin) {
                            // Un service fait avancer la demande ; il ne réécrit pas ce que le client a dit.
                            $autres = array_intersect_key($autres, ['commentaire' => 1]);
                        }
                        $parQui = (string) ($d['pris_par'] ?? $d['traite_par'] ?? '') ?: (string) ($user['nom'] ?? '');
                        if ($autres) {
                            update($db, 'rep_demandes', $id, $autres);
                            $chg = array_keys(array_filter($autres, fn($v, $k) => (string) $v !== (string) ($dem[$k] ?? ''), ARRAY_FILTER_USE_BOTH));
                            if ($chg) {
                                ma_rep_evenement($db, $id, 'modifiee', $user['nom'] ?? ($viaApiKey ? 'Make' : null), $viaApiKey ? 'make' : 'plateforme',
                                    'Informations modifiées : ' . implode(', ', $chg), array_intersect_key($autres, array_flip($chg)));
                            }
                        }
                        if ($etapes) {
                            try {
                                ma_rep_avancer($db, $id, $etapes, $parQui);
                            } catch (RuntimeException $e) {
                                fail($e->getMessage(), 404);
                            }
                        }
                        out(['ok' => true, 'demande' => getOne($db, 'rep_demandes', $id)]);
                    }
                    if ($method === 'DELETE') {
                        if (!$estAdmin) {
                            fail('Seul un administrateur peut supprimer une demande', 403);
                        }
                        $db->prepare('DELETE FROM rep_demandes WHERE id = ?')->execute([$id]);
                        out(['ok' => true]);
                    }
                    $dem['liens'] = ma_rep_liens($db, $dem);
                    if (!empty($dem['client_id']) && ($cl = getOne($db, 'rep_clients', (int) $dem['client_id']))) {
                        $dem['client'] = ['id' => (int) $cl['id'], 'nb_demandes' => (int) $cl['nb_demandes'], 'fidelite' => ma_client_fidelite($cl),
                            'premiere_demande' => $cl['premiere_demande'], 'notes' => $cl['notes']];
                    }
                    if ($sub3 = ($parts[3] ?? null)) {
                        if ($sub3 === 'historique') {
                            out(['ok' => true, 'historique' => ma_rep_historique($db, $dem)]);
                        }
                    }
                    out(['ok' => true, 'demande' => $dem, 'historique' => ma_rep_historique($db, $dem)]);
                }
                $q = $_GET;
                if ($portee !== null) {
                    $q['service'] = $portee;
                }
                out(['ok' => true, 'rows' => listRows($db, 'rep_demandes', 'created_at', $q, ['societe', 'contact', 'tel', 'resume', 'marque', 'modele'])]);
            }
            if ($sub === 'routage') {
                routageRoutes($db, 'repondeur', $sub2, $method, $body);
            }
            // Annuaire (rep/contacts) et règles de routage (rep/regles) : même mécanique.
            if ($sub === 'contacts' || $sub === 'regles') {
                $table = $sub === 'contacts' ? 'rep_contacts' : 'rep_regles';
                $norm = function (array $d) use ($sub): array {
                    foreach (['actif', 'externe'] as $b) {
                        if (array_key_exists($b, $d)) {
                            $d[$b] = ma_bool($d[$b]) ? 1 : 0;
                        }
                    }
                    if ($sub === 'regles' && isset($d['ordre'])) {
                        $d['ordre'] = (int) $d['ordre'];
                    }
                    if ($sub === 'contacts' && isset($d['mobile'])) {
                        $d['mobile'] = ma_str($d['mobile']);
                    }
                    // Le mot de passe ne s'écrit que par le lien d'invitation (compte.php).
                    unset($d['mdp_hash'], $d['mdp_jeton'], $d['mdp_jeton_exp'], $d['derniere_connexion']);
                    return $d;
                };
                if ($method === 'POST' && $sub2 === null) {
                    $d = $norm($body);
                    if ($sub === 'contacts' && (trim((string) ($d['nom'] ?? '')) === '' || trim((string) ($d['role'] ?? '')) === '')) {
                        fail('Nom et rôle requis');
                    }
                    if ($sub === 'regles' && trim((string) ($d['cible'] ?? '')) === '') {
                        fail('Cible requise');
                    }
                    $id = insert($db, $table, $d);
                    $l = getOne($db, $table, $id);
                    out(['ok' => true, 'id' => $id, 'ligne' => $sub === 'contacts' ? ma_contact_public($l) : $l]);
                }
                if ($sub2 !== null) {
                    $id = idFrom($parts, 2);
                    if ($method === 'PATCH' || $method === 'POST') {
                        update($db, $table, $id, $norm($body));
                        $l = getOne($db, $table, $id);
                        out(['ok' => true, 'ligne' => $sub === 'contacts' ? ma_contact_public($l) : $l]);
                    }
                    if ($method === 'DELETE') {
                        $db->prepare("DELETE FROM $table WHERE id = ?")->execute([$id]);
                        out(['ok' => true]);
                    }
                    $l = getOne($db, $table, $id) ?? fail('Introuvable', 404);
                    out(['ok' => true, 'ligne' => $sub === 'contacts' ? ma_contact_public($l) : $l]);
                }
                $ordre = $sub === 'contacts' ? 'role, nom' : 'ordre, id';
                $rows = $db->query("SELECT * FROM $table ORDER BY $ordre")->fetchAll();
                out(['ok' => true, 'rows' => $sub === 'contacts' ? array_map('ma_contact_public', $rows) : $rows,
                    'parametres' => $db->query("SELECT cle, valeur FROM parametres WHERE cle IN ('rep_repli_email','rep_cc_urgence')")
                        ->fetchAll(PDO::FETCH_KEY_PAIR)]);
            }
            // Tableaux « qui reçoit quoi » par service (écran de routage). Les règles en découlent.
            if ($sub === 'grilles') {
                if ($method === 'POST' || $method === 'PATCH') {
                    ma_rep_grilles_enregistrer($db, $body);
                    logEvent($db, 'repondeur', 'ok', 'routage_modifie', 'Tableaux de routage mis à jour depuis la page');
                }
                out(['ok' => true, 'grilles' => ma_rep_grilles_lire($db)]);
            }
            // Listes paramétrables : marques, natures de demande, rôles de l'annuaire.
            if ($sub === 'listes') {
                if ($method === 'POST' || $method === 'PATCH') {
                    foreach (['marques', 'natures', 'roles'] as $cle) {
                        if (!isset($body[$cle]) || !is_array($body[$cle])) {
                            continue;
                        }
                        $liste = [];
                        foreach ($body[$cle] as $x) {
                            $code = preg_replace('/[^a-z0-9_]/', '', str_replace([' ', '-'], '_', ma_plat($x['code'] ?? '')));
                            if ($code !== '') {
                                $liste[] = ['code' => $code, 'libelle' => trim((string) ($x['libelle'] ?? '')) ?: $code,
                                    'mots' => trim((string) ($x['mots'] ?? ''))];
                            }
                        }
                        if (!$liste) {
                            fail("La liste « $cle » ne peut pas être vide");
                        }
                        $db->prepare('INSERT OR REPLACE INTO parametres(cle, valeur) VALUES (?,?)')
                            ->execute(['rep_liste_' . $cle, json_encode($liste, JSON_UNESCAPED_UNICODE)]);
                    }
                }
                out(['ok' => true] + ma_rep_listes($db));
            }
            // Aperçu des messages envoyés au client, sur la dernière demande (ou un exemple).
            if ($sub === 'apercu') {
                $dem = $db->query("SELECT * FROM rep_demandes WHERE jeton_client IS NOT NULL ORDER BY id DESC LIMIT 1")->fetch()
                    ?: ['id' => 0, 'service' => 'SAV', 'contact' => 'Monsieur Martin', 'marque' => 'Worthington Creyssensac', 'modele' => 'ROLLAIR 220',
                        'type_panne' => 'Le compresseur ne redémarre plus', 'jeton_client' => str_repeat('0', 32), 'priorite' => 'Normal'];
                $dem['pris_par'] = $dem['pris_par'] ?: 'Julien Jardin';
                $dem['rappel_prevu'] = $dem['rappel_prevu'] ?: date('Y-m-d 10:00:00', strtotime('+1 day'));
                $out = [];
                foreach (['recue' => 'Demande reçue', 'prise_en_charge' => 'Prise en charge', 'rappel' => 'Rappel prévu', 'traitee' => 'Demande traitée'] as $evt => $nom) {
                    $out[] = ['evenement' => $evt, 'nom' => $nom, 'texte' => ma_rep_texte_client($db, $dem, $evt), 'html' => ma_rep_html_client($db, $dem, $evt)];
                }
                out(['ok' => true, 'demande_id' => (int) $dem['id'], 'messages' => $out, 'standard' => ma_param($db, 'rep_standard_tel', '01 34 32 95 00')]);
            }
            // Simulateur : qui recevrait cette demande ? Rien n'est enregistré ni envoyé.
            if ($sub === 'simuler') {
                out(['ok' => true] + ma_rep_router($db, $body + $_GET));
            }
            fail('Route rep inconnue', 404);

        // ============================================================ Équipe et accès
        case 'equipe':
            if (!$estAdmin) {
                // Un service n'a besoin que des noms (« pris en charge par »).
                $rows = $db->query("SELECT * FROM rep_contacts WHERE actif = 1 ORDER BY nom")->fetchAll();
                out(['ok' => true, 'rows' => array_map(fn($c) => ['id' => (int) $c['id'], 'nom' => $c['nom'], 'fonction' => $c['fonction'], 'role' => $c['role'],
                    'commentaire' => $c['commentaire'], 'competences' => $c['competences'], 'service_equipe' => ma_contact_service($c),
                    'joignable' => (bool) ma_liste_emails($c['email'] ?? null)], $rows),
                    'responsables' => array_map(fn($r) => $r ? (int) $r['id'] : null, ma_responsables($db))]);
            }
            $normEquipe = function (array $d) use ($db): array {
                $d = array_intersect_key($d, array_flip(['nom', 'fonction', 'service', 'acces', 'email', 'mobile', 'role', 'departements',
                    'marques', 'competences', 'membres', 'actif', 'commentaire', 'externe']));
                foreach (['actif', 'externe'] as $b) {
                    if (array_key_exists($b, $d)) {
                        $d[$b] = ma_bool($d[$b]) ? 1 : 0;
                    }
                }
                if (array_key_exists('acces', $d)) {
                    $d['acces'] = isset(MA_ACCES[$d['acces']]) ? $d['acces'] : null;
                    if ($d['acces'] && !str_contains((string) ($d['email'] ?? ''), '@')) {
                        fail('Une adresse e-mail est nécessaire pour ouvrir un accès : c\'est l\'identifiant de connexion');
                    }
                }
                if (array_key_exists('email', $d) && trim((string) $d['email']) !== '') {
                    $d['email'] = trim((string) $d['email']);
                }
                foreach (['mobile', 'fonction', 'departements'] as $c) {
                    if (array_key_exists($c, $d)) {
                        $d[$c] = ma_str($d[$c]);
                    }
                }
                return $d;
            };
            $unique = function (array $d, int $id = 0) use ($db): void {
                if (trim((string) ($d['email'] ?? '')) === '' || empty($d['acces'])) {
                    return;
                }
                $st = $db->prepare("SELECT nom FROM rep_contacts WHERE lower(email) = lower(?) AND id != ? AND acces IN ('admin','sav','commerce','finance')");
                $st->execute([$d['email'], $id]);
                if ($autre = $st->fetchColumn()) {
                    fail("Cette adresse sert déjà d'identifiant à $autre");
                }
            };
            if ($sub === 'responsables' && ($method === 'POST' || $method === 'PATCH')) {
                $ins = $db->prepare('INSERT OR REPLACE INTO parametres(cle, valeur) VALUES (?, ?)');
                foreach (['sav' => 'resp_sav', 'finance' => 'resp_finance', 'commercial' => 'resp_commerce', 'autre' => 'resp_indetermine'] as $k => $cle) {
                    if (isset($body[$k])) {
                        $ins->execute([$cle, (string) (int) $body[$k]]);
                    }
                }
                logEvent($db, 'plateforme', 'ok', 'responsables_modifies', 'Responsables de service mis à jour' . ($user ? ' par ' . $user['nom'] : ''));
            } elseif ($method === 'POST' && $sub === null) {
                $d = $normEquipe($body) + ['role' => 'membre', 'actif' => 1];
                if (trim((string) ($d['nom'] ?? '')) === '') {
                    fail('Le nom est requis');
                }
                $unique($d);
                $id = insert($db, 'rep_contacts', $d);
                logEvent($db, 'plateforme', 'ok', 'equipe_ajout', $d['nom'] . ' ajouté(e) à l\'équipe' . ($user ? ' par ' . $user['nom'] : ''));
                out(['ok' => true, 'id' => $id, 'personne' => ma_contact_public(getOne($db, 'rep_contacts', $id))]);
            } elseif ($sub !== null && $sub !== 'responsables') {
                $id = idFrom($parts, 1);
                $c = getOne($db, 'rep_contacts', $id) ?? fail('Personne introuvable', 404);
                if ($sub2 === 'invitation' && $method === 'POST') {
                    if (!isset(MA_ACCES[$c['acces'] ?? '']) || !str_contains((string) $c['email'], '@')) {
                        fail('Donnez d\'abord un accès et une adresse e-mail à cette personne');
                    }
                    $r = ma_compte_lien($db, $c, trim((string) $c['mdp_hash']) !== '' ? 'reinit' : 'invitation');
                    out(['ok' => true] + $r);
                }
                if ($method === 'PATCH' || $method === 'POST') {
                    $d = $normEquipe($body);
                    $unique($d + ['email' => $c['email'], 'acces' => $c['acces']], $id);
                    if (array_key_exists('acces', $d) && !$d['acces']) {
                        // Accès retiré : le mot de passe ne sert plus.
                        $d['mdp_hash'] = null;
                    }
                    $cols = array_keys($d);
                    if ($cols) {
                        $db->prepare('UPDATE rep_contacts SET ' . implode(', ', array_map(fn($k) => "$k = ?", $cols)) . ' WHERE id = ?')
                            ->execute([...array_values($d), $id]);
                    }
                    out(['ok' => true, 'personne' => ma_contact_public(getOne($db, 'rep_contacts', $id))]);
                }
                if ($method === 'DELETE') {
                    $db->prepare('DELETE FROM rep_contacts WHERE id = ?')->execute([$id]);
                    logEvent($db, 'plateforme', 'ok', 'equipe_retrait', $c['nom'] . ' retiré(e) de l\'équipe' . ($user ? ' par ' . $user['nom'] : ''));
                    out(['ok' => true]);
                }
                out(['ok' => true, 'personne' => ma_contact_public($c)]);
            }
            $rows = $db->query('SELECT * FROM rep_contacts ORDER BY nom')->fetchAll();
            $resp = ma_responsables($db);
            out(['ok' => true, 'rows' => array_map('ma_contact_public', $rows),
                'responsables' => array_map(fn($r) => $r ? (int) $r['id'] : null, $resp),
                'acces' => MA_ACCES, 'services' => MA_SERVICES,
                'parametres' => $db->query("SELECT cle, valeur FROM parametres WHERE cle IN ('rep_repli_email','rep_cc_urgence','rep_standard_tel')")
                    ->fetchAll(PDO::FETCH_KEY_PAIR)]);

        // ============================================================ Clients (base et reconnaissance)
        case 'clients':
            // Claire (VAPI) appelle cet outil en début d'appel : le numéro de l'appelant est dans l'appel.
            if ($sub === 'vapi') {
                $msg = $body['message'] ?? [];
                $numero = (string) ($msg['call']['customer']['number'] ?? ($msg['customer']['number'] ?? ($body['tel'] ?? ($_GET['tel'] ?? ''))));
                $appels = $msg['toolCallList'] ?? ($msg['toolCalls'] ?? []);
                $args = [];
                foreach ($appels as $a) {
                    $x = $a['function']['arguments'] ?? ($a['arguments'] ?? []);
                    $args = is_string($x) ? (json_decode($x, true) ?: []) : (array) $x;
                }
                $r = ma_client_reconnaitre($db, (string) ($args['telephone'] ?? '') ?: $numero, (string) ($args['email'] ?? ''));
                logEvent($db, 'repondeur', 'info', 'appelant_' . ($r['connu'] ? 'reconnu' : 'inconnu'),
                    ($r['connu'] ? 'Appelant reconnu : ' . ($r['contact'] ?? '') . ($r['societe'] ? ' (' . $r['societe'] . ')' : '') : 'Appelant inconnu') . ' — ' . ma_tel_lisible($numero));
                $texte = $r['contexte'];
                if ($appels) {
                    out(['results' => array_map(fn($a) => ['toolCallId' => $a['id'] ?? ($a['toolCallId'] ?? ''), 'result' => $texte], $appels)]);
                }
                out(['ok' => true] + $r);
            }
            if ($sub === 'reconnaitre') {
                out(['ok' => true] + ma_client_reconnaitre($db, (string) ($_GET['tel'] ?? ($body['tel'] ?? '')), (string) ($_GET['email'] ?? ($body['email'] ?? ''))));
            }
            if ($sub === 'reconstruire' && $method === 'POST' && $estAdmin) {
                out(['ok' => true, 'rattachees' => ma_clients_reprise($db)]);
            }
            if ($sub !== null) {
                $id = idFrom($parts, 1);
                $c = getOne($db, 'rep_clients', $id) ?? fail('Client introuvable', 404);
                // Parc machines : ajouter, corriger, retirer une machine.
                if ($sub2 === 'equipements' && $method !== 'GET') {
                    $eid = (int) ($parts[3] ?? 0);
                    $e = $eid ? (getOne($db, 'rep_equipements', $eid) ?? fail('Machine introuvable', 404)) : null;
                    if ($e && (int) $e['client_id'] !== $id) {
                        fail('Machine d\'un autre client', 400);
                    }
                    if ($method === 'DELETE' && $e) {
                        $db->prepare('UPDATE rep_demandes SET equipement_id = NULL WHERE equipement_id = ?')->execute([$eid]);
                        $db->prepare('DELETE FROM rep_equipements WHERE id = ?')->execute([$eid]);
                        logEvent($db, 'plateforme', 'ok', 'machine_retiree', 'Machine retirée du parc du client ' . $id . ($user ? ' par ' . $user['nom'] : ''));
                    } else {
                        $d = array_map(fn($v) => is_string($v) ? (trim($v) === '' ? null : trim($v)) : $v,
                            array_intersect_key($body, array_flip(['marque', 'modele', 'numero_serie', 'type_equipement', 'code_postal', 'departement', 'commentaire', 'actif'])));
                        if (isset($d['actif'])) {
                            $d['actif'] = ma_bool($d['actif']) ? 1 : 0;
                        }
                        if (!empty($d['code_postal'])) {
                            $d['departement'] = ma_departement($d['code_postal']) ?? ($d['departement'] ?? null);
                        }
                        $d['updated_at'] = $now;
                        if ($e) {
                            update($db, 'rep_equipements', $eid, $d);
                        } else {
                            if (empty($d['marque']) && empty($d['modele']) && empty($d['numero_serie'])) {
                                fail('Indiquez au moins la marque, le modèle ou le numéro de série');
                            }
                            insert($db, 'rep_equipements', $d + ['client_id' => $id, 'source' => 'manuel', 'created_at' => $now]);
                        }
                        logEvent($db, 'plateforme', 'ok', $e ? 'machine_corrigee' : 'machine_ajoutee', 'Parc du client ' . $id . ($user ? ' — ' . $user['nom'] : ''));
                    }
                } elseif ($sub2 === 'fusionner' && $method === 'POST' && $estAdmin) {
                    $autre = (int) ($body['avec'] ?? 0);
                    getOne($db, 'rep_clients', $autre) ?? fail('Fiche à fusionner introuvable', 404);
                    ma_clients_fusionner($db, $id, $autre);
                    logEvent($db, 'plateforme', 'ok', 'clients_fusionnes', "Fiche client $autre fusionnée dans $id" . ($user ? ' par ' . $user['nom'] : ''));
                    $c = getOne($db, 'rep_clients', $id);
                } elseif (($method === 'PATCH' || $method === 'POST') && $estAdmin) {
                    $identite = ['contact', 'societe', 'tel', 'email', 'type_client', 'type_interlocuteur', 'code_postal', 'departement', 'compte_distributeur'];
                    $d = array_intersect_key($body, array_flip([...$identite, 'statut_client', 'notes']));
                    if (array_key_exists('tel', $d)) {
                        $d['tel'] = ma_tel_cle((string) $d['tel']);
                    }
                    if (!empty($d['code_postal'])) {
                        $d['departement'] = ma_departement((string) $d['code_postal']);
                    }
                    // Une correction faite ici ne sera plus écrasée par les demandes suivantes.
                    $corr = ma_csv($c['champs_corriges'] ?? '');
                    foreach ($identite as $k) {
                        if (array_key_exists($k, $d) && (string) $d[$k] !== (string) ($c[$k] ?? '')) {
                            $corr[] = $k;
                        }
                    }
                    $d['champs_corriges'] = implode(',', array_unique($corr));
                    $d['updated_at'] = $now;
                    update($db, 'rep_clients', $id, $d);
                    logEvent($db, 'plateforme', 'ok', 'client_modifie', 'Fiche client ' . $id . ' modifiée' . ($user ? ' par ' . $user['nom'] : ''));
                    $c = getOne($db, 'rep_clients', $id);
                }
                $q = 'SELECT * FROM rep_demandes WHERE client_id = ?' . ($portee !== null ? ' AND service = ?' : '') . ' ORDER BY created_at DESC';
                $st = $db->prepare($q);
                $st->execute($portee !== null ? [$id, $portee] : [$id]);
                $c['demandes'] = $st->fetchAll();
                $c['fidelite'] = ma_client_fidelite($c);
                $st = $db->prepare('SELECT * FROM rep_equipements WHERE client_id = ? ORDER BY actif DESC, COALESCE(derniere_demande, created_at) DESC');
                $st->execute([$id]);
                $c['equipements'] = $st->fetchAll();
                // Devis CSO au même e-mail ou au même numéro : ce que le client achète chez nous.
                $st = $db->prepare("SELECT id, n_offre, date_offre, montant_ht, statut, commercial FROM cso_devis
                    WHERE (email_client IS NOT NULL AND lower(email_client) = lower(?)) OR (tel_client IS NOT NULL AND tel_client != '' AND ? != '' AND replace(replace(tel_client, ' ', ''), '.', '') LIKE ?)
                    ORDER BY date_traitement DESC");
                $local = preg_match('/^33(\d{9})$/', (string) $c['tel'], $m) ? '0' . $m[1] : (string) $c['tel'];
                $st->execute([(string) $c['email'], $local, '%' . substr($local, -9)]);
                $c['devis'] = $estAdmin ? $st->fetchAll() : [];
                $c['reconnaissance'] = ma_client_reconnaitre($db, $c['tel'], $c['email']);
                out(['ok' => true, 'client' => $c]);
            }
            $rows = $db->query('SELECT c.*, (SELECT COUNT(*) FROM rep_demandes d WHERE d.client_id = c.id AND d.statut != \'traite\') AS nb_ouvertes,
                (SELECT group_concat(DISTINCT d.service) FROM rep_demandes d WHERE d.client_id = c.id) AS services,
                (SELECT group_concat(DISTINCT d.canal) FROM rep_demandes d WHERE d.client_id = c.id) AS canaux
                FROM rep_clients c WHERE c.nb_demandes > 0 ORDER BY c.derniere_demande DESC')->fetchAll();
            foreach ($rows as &$r) {
                $r['fidelite'] = ma_client_fidelite($r);
            }
            unset($r);
            out(['ok' => true, 'rows' => $rows]);

        case 'distributeurs':
            if ($sub === 'find') {
                // Remplace filterRows DISTRIBUTEUR (col D = raison sociale, insensible à la casse)
                $s = trim((string) ($_GET['societe'] ?? ''));
                if ($s === '') {
                    out(['ok' => true, 'trouve' => false, 'distributeur' => null]);
                }
                $st = $db->prepare('SELECT * FROM distributeurs WHERE raison_sociale = ? COLLATE NOCASE LIMIT 1');
                $st->execute([$s]);
                $r = $st->fetch();
                if (!$r) {
                    $st = $db->prepare('SELECT * FROM distributeurs WHERE raison_sociale LIKE ? COLLATE NOCASE ORDER BY length(raison_sociale) LIMIT 1');
                    $st->execute(['%' . $s . '%']);
                    $r = $st->fetch();
                }
                out(['ok' => true, 'trouve' => (bool) $r, 'distributeur' => $r ?: null,
                    'commercial' => $r['vendeur'] ?? '', 'compte' => $r['compte'] ?? '', 'extra' => $r['raison_sociale'] ?? '']);
            }
            if ($method === 'POST' && $sub === null) {
                $id = insert($db, 'distributeurs', $body);
                out(['ok' => true, 'id' => $id]);
            }
            if ($sub !== null) {
                $id = idFrom($parts, 1);
                if ($method === 'PATCH' || $method === 'POST') {
                    update($db, 'distributeurs', $id, $body);
                    out(['ok' => true, 'distributeur' => getOne($db, 'distributeurs', $id)]);
                }
                if ($method === 'DELETE') {
                    $db->prepare('DELETE FROM distributeurs WHERE id = ?')->execute([$id]);
                    out(['ok' => true]);
                }
            }
            $q = $_GET;
            $q['order'] = $q['order'] ?? 'raison_sociale';
            $q['dir'] = $q['dir'] ?? 'asc';
            out(['ok' => true, 'rows' => listRows($db, 'distributeurs', 'raison_sociale', $q, ['raison_sociale', 'vendeur', 'compte', 'nom', 'prenom', 'email', 'marque'])]);

        // ============================================================ Chatbot Claire
        case 'chat':
            if ($sub === 'messages') {
                if ($method === 'POST') {
                    $d = [
                        'session_id' => ma_str($body['session_id'] ?? null),
                        'date' => ma_date($body['date'] ?? null) ?? $now,
                        'message' => ma_str($body['message'] ?? null),
                        'reponse' => ma_str($body['reponse'] ?? $body['reply'] ?? null),
                        'page_url' => ma_str($body['page_url'] ?? null),
                    ];
                    $id = insert($db, 'chat_messages', $d);
                    out(['ok' => true, 'id' => $id]);
                }
                out(['ok' => true, 'rows' => listRows($db, 'chat_messages', 'date', $_GET, ['message', 'reponse', 'session_id', 'page_url'])]);
            }
            if ($sub === 'sessions') {
                $rows = $db->query("SELECT session_id, MIN(date) AS debut, MAX(date) AS fin, COUNT(*) AS nb_messages, MIN(page_url) AS page_url,
                        (SELECT message FROM chat_messages m2 WHERE m2.session_id = m.session_id ORDER BY date, id LIMIT 1) AS premier_message,
                        (SELECT COUNT(*) FROM chat_leads l WHERE l.session_id = m.session_id) AS nb_leads
                    FROM chat_messages m GROUP BY session_id ORDER BY fin DESC LIMIT 2000")->fetchAll();
                out(['ok' => true, 'rows' => $rows]);
            }
            if ($sub === 'leads') {
                if ($sub2 === 'dedup') {
                    // Regroupement des doublons déjà enregistrés (import historique)
                    $r = ma_chat_dedup($db);
                    logEvent($db, 'chatbot', 'ok', 'dedup', $r['fusionnes'] . ' doublon(s) fusionné(s), ' . $r['restants'] . ' lead(s) restant(s)', $r);
                    out(['ok' => true] + $r);
                }
                if ($method === 'POST' && $sub2 === null) {
                    // Regroupement : un lead identique (session, société+nom, email ou téléphone) reçu dans la
                    // fenêtre paramétrée (chat_lead_fenetre_min, 60 min par défaut) met à jour le lead existant.
                    $d = $body;
                    $d['date'] = ma_date($d['date'] ?? null) ?? $now;
                    $d['marque_orientee'] = $d['marque_orientee'] ?? ($d['marque'] ?? null);
                    $r = ma_chat_lead_upsert($db, $d);
                    logEvent($db, 'chatbot', 'ok', $r['action'] === 'created' ? 'lead' : 'lead_maj',
                        ($d['societe'] ?? '') . ' - ' . ($d['prenom'] ?? '') . ' ' . ($d['nom'] ?? '') . ' [' . ($d['categorie'] ?? '') . ']' . ($r['action'] === 'merged' ? ' (mise à jour n°' . $r['nb_mises_a_jour'] . ')' : ''), ['id' => $r['id']]);
                    // Le lead devient une demande, routée comme celles du répondeur : le scénario du chatbot
                    // envoie son e-mail interne aux destinataires renvoyés ici.
                    $dm = ma_chat_demande($db, $r['id']);
                    $rt = $dm['rt'] ?? ['to' => '', 'cc' => '', 'regle_libelle' => '', 'sms' => '', 'urgent' => false, 'objet' => '', 'mail_html' => '', 'sms_texte' => ''];
                    out(['ok' => true, 'id' => $r['id'], 'action' => $r['action'], 'nouveau' => $r['action'] === 'created' || !empty($dm['nouvelle']),
                        'nb_mises_a_jour' => $r['nb_mises_a_jour'], 'demande_id' => $dm['id'] ?? null,
                        'dest_to' => $rt['to'], 'dest_cc' => $rt['cc'], 'dest_libelle' => ($dm['demande']['destinataires'] ?? '') ?: $rt['regle_libelle'],
                        'service' => $dm['demande']['service'] ?? null, 'urgent' => $rt['urgent'], 'sms' => $rt['sms'], 'sms_texte' => $rt['sms_texte'],
                        'objet' => $rt['objet'], 'mail_html' => $rt['mail_html'],
                        'lien_interne' => $dm['liens']['interne'] ?? '', 'lien_client' => $dm['liens']['client'] ?? '']);
                }
                if ($sub2 !== null) {
                    $id = idFrom($parts, 2);
                    if ($method === 'PATCH' || $method === 'POST') {
                        update($db, 'chat_leads', $id, $body);
                        out(['ok' => true, 'lead' => getOne($db, 'chat_leads', $id)]);
                    }
                    if ($method === 'DELETE') {
                        $db->prepare('DELETE FROM chat_leads WHERE id = ?')->execute([$id]);
                        out(['ok' => true]);
                    }
                    out(['ok' => true, 'lead' => getOne($db, 'chat_leads', $id)]);
                }
                out(['ok' => true, 'rows' => listRows($db, 'chat_leads', 'date', $_GET, ['societe', 'nom', 'prenom', 'email', 'telephone', 'besoin_resume', 'departement'])]);
            }
            if ($sub === 'routage') {
                $_GET['cle'] = $_GET['cle'] ?? ($_GET['categorie'] ?? null);
                $body['cle'] = $body['cle'] ?? ($body['categorie'] ?? null);
                routageRoutes($db, 'chatbot', $sub2, $method, $body);
            }
            fail('Route chat inconnue', 404);

        // ============================================================ Claire ADV
        case 'adv':
            if ($sub === 'demandes') {
                if ($method === 'POST' && $sub2 === null) {
                    // Reçoit la réponse brute de l'agent et la découpe (bloc [ANALYSE] --- [AUTO|ESCALADE] mail)
                    $resp = (string) ($body['response'] ?? $body['reponse_ia'] ?? '');
                    $analyse = null;
                    $mail = $resp;
                    if (str_contains($resp, '---')) {
                        $pos = strrpos($resp, '---');
                        $analyse = trim(substr($resp, 0, $pos));
                        $mail = trim(substr($resp, $pos + 3));
                    }
                    $tag = null;
                    foreach (['ESCALADE', 'AUTO', 'DRAFT'] as $t) {
                        if (stripos($resp, "[$t]") !== false) {
                            $tag = $t;
                            break;
                        }
                    }
                    $tag = ma_str($body['tag'] ?? null) ?? $tag ?? ($resp === '' ? 'RECU' : 'AUTO');
                    $mailClean = trim(str_ireplace(['[AUTO]', '[DRAFT]', '[ESCALADE]'], '', $mail));
                    $champ = function (string $label) use ($analyse): ?string {
                        if ($analyse === null) {
                            return null;
                        }
                        if (preg_match('/' . preg_quote($label, '/') . '\s*:\s*(.+)/i', $analyse, $m)) {
                            return trim($m[1]);
                        }
                        return null;
                    };
                    $famille = ma_str($body['famille'] ?? null) ?? ($resp === '' ? null
                        : ((($analyse !== null && stripos($analyse, '[ANALYSE]') !== false) ? 'equipements'
                            : ((stripos($resp, 'maintenance') !== false || stripos($resp, 'Cadence des visites') !== false) ? 'maintenance' : 'equipements'))));
                    $d = [
                        'date' => ma_date($body['date'] ?? null) ?? $now,
                        'message_id' => ma_str($body['message_id'] ?? null),
                        'from_email' => ma_str($body['from_email'] ?? null),
                        'from_nom' => ma_str($body['from_nom'] ?? null),
                        'sujet' => ma_str($body['sujet'] ?? $body['subject'] ?? null),
                        'message' => ma_str($body['message'] ?? $body['text'] ?? null),
                        'famille' => $famille,
                        'cas' => ma_str($body['cas'] ?? null) ?? ($champ('Cas') ? strtoupper($champ('Cas')) : null),
                        'techno' => $champ('Techno'),
                        'critere' => $champ('Critere') ?? $champ('Critère'),
                        'pression' => $champ('Pression'),
                        'configuration' => $champ('Configuration'),
                        'options_retenues' => $champ('Options retenues'),
                        'tag' => $tag,
                        'analyse_brute' => $analyse,
                        'reponse_ia' => $resp,
                        'mail_envoye' => ma_str($body['mail_envoye'] ?? null) ?? $mailClean,
                        'envoye_at' => ma_bool($body['envoye'] ?? ($tag === 'AUTO')) ? $now : null,
                        'statut_suivi' => $tag === 'RECU' ? 'recu' : ($tag === 'AUTO' ? 'envoye' : 'a_valider'),
                        'commentaire' => ma_str($body['commentaire'] ?? null),
                    ];
                    // Le scénario écrit deux fois : à la réception du mail (tag RECU) puis après
                    // la réponse de Claire. Même Message-ID = même demande, on complète la ligne.
                    $existant = null;
                    if ($d['message_id'] !== null && $d['message_id'] !== '') {
                        $st = $db->prepare('SELECT * FROM adv_demandes WHERE message_id = ? ORDER BY id DESC LIMIT 1');
                        $st->execute([$d['message_id']]);
                        $existant = $st->fetch() ?: null;
                    }
                    $action = 'created';
                    if ($existant) {
                        $action = 'updated';
                        $id = (int) $existant['id'];
                        if ($tag === 'RECU') {
                            // Le mail est déjà journalisé (rejeu du webhook) : on ne touche à rien.
                            $maj = [];
                        } else {
                            $maj = array_filter($d, fn($v) => $v !== null && $v !== '');
                            unset($maj['date'], $maj['message_id'], $maj['commentaire']);
                        }
                        if ($maj) {
                            update($db, 'adv_demandes', $id, $maj);
                        }
                    } else {
                        $id = insert($db, 'adv_demandes', $d);
                    }
                    logEvent($db, 'adv', $tag === 'ERREUR' ? 'erreur' : 'ok', $tag === 'RECU' ? 'mail_recu' : 'mail_traite',
                        ($d['from_email'] ?? '') . ' - ' . ($d['sujet'] ?? '') . ' [' . $tag . ']', ['id' => $id]);
                    $cleRoutage = in_array($tag, ['ESCALADE', 'ERREUR'], true) ? $tag : ($famille === 'maintenance' ? 'MAINTENANCE' : ($d['cas'] ?? 'STANDARD'));
                    $rt = ma_routage($db, 'adv', $cleRoutage);
                    out(['ok' => true, 'id' => $id, 'action' => $action, 'tag' => $tag, 'famille' => $famille, 'cas' => $d['cas'], 'mail' => $mailClean, 'statut_suivi' => $d['statut_suivi'],
                        'envoyer_au_client' => $tag === 'AUTO', 'routage_cle' => $cleRoutage, 'dest_to' => $rt['dest_to'], 'dest_cc' => $rt['dest_cc'], 'dest_libelle' => $rt['dest_libelle']]);
                }
                if ($sub2 !== null) {
                    $id = idFrom($parts, 2);
                    if ($method === 'PATCH' || $method === 'POST') {
                        $d = $body;
                        if (in_array($d['statut_suivi'] ?? '', ['valide', 'traite'], true)) {
                            $d['traite_at'] = $now;
                        }
                        update($db, 'adv_demandes', $id, $d);
                        out(['ok' => true, 'demande' => getOne($db, 'adv_demandes', $id)]);
                    }
                    if ($method === 'DELETE') {
                        $db->prepare('DELETE FROM adv_demandes WHERE id = ?')->execute([$id]);
                        out(['ok' => true]);
                    }
                    out(['ok' => true, 'demande' => getOne($db, 'adv_demandes', $id)]);
                }
                out(['ok' => true, 'rows' => listRows($db, 'adv_demandes', 'date', $_GET, ['from_email', 'from_nom', 'sujet', 'message', 'techno', 'critere'])]);
            }
            if ($sub === 'routage') {
                routageRoutes($db, 'adv', $sub2, $method, $body);
            }
            fail('Route adv inconnue', 404);

        // ============================================================ CSO devis
        case 'cso':
            if ($sub === 'devis') {
                if ($sub2 === 'find') {
                    $n = trim((string) ($_GET['n_offre'] ?? ''));
                    $st = $db->prepare('SELECT * FROM cso_devis WHERE n_offre = ?');
                    $st->execute([$n]);
                    $r = $st->fetch();
                    out(['ok' => true, 'trouve' => (bool) $r, 'devis' => $r ?: null]);
                }
                if ($sub2 === 'relances_dues' || $sub2 === 'relances_prevues') {
                    // relances_dues : ce que le scénario Make envoie aujourd'hui.
                    // relances_prevues : toutes les relances programmées, pour l'aperçu dans la page.
                    $due = ma_relances_planifiees($db, $sub2 === 'relances_dues', !empty($_GET['inclure_ecart']));
                    out(['ok' => true, 'nb' => count($due), 'rows' => $due]);
                }
                if ($sub2 === 'modeles_relance') {
                    out(['ok' => true, 'modeles' => ma_relance_modeles($db)]);
                }
                if ($method === 'POST' && $sub2 === null) {
                    // Upsert complet : remplace makeAPICall B2:B + addRow/updateRow Devis + addRow/delete Lignes
                    $d = $body;
                    if (array_key_exists('est_un_devis', $d) && !ma_bool($d['est_un_devis'])) {
                        logEvent($db, 'cso', 'ok', 'ignore', 'Pièce jointe non reconnue comme devis : ' . ($d['fichier_source'] ?? ''), null);
                        out(['ok' => true, 'action' => 'ignore']);
                    }
                    $n = ma_str($d['n_offre'] ?? $d['numero_offre'] ?? null) ?? fail('numero_offre requis');
                    $lignes = is_array($d['lignes'] ?? null) ? $d['lignes'] : [];
                    if (is_string($d['lignes'] ?? null)) {
                        $lignes = json_decode($d['lignes'], true) ?: [];
                    }
                    $montantHt = ma_float($d['montant_ht'] ?? null);
                    $refs = [];
                    $sum = 0.0;
                    foreach ($lignes as $l) {
                        $refs[] = (string) ($l['reference'] ?? '');
                        $sum += (float) (ma_float($l['prix_total_ht'] ?? null) ?? 0);
                    }
                    $empreinte = implode('-', $refs) . '|' . ($montantHt === null ? '' : rtrim(rtrim(number_format($montantHt, 2, '.', ''), '0'), '.'));
                    $controle = ($montantHt !== null && abs(round($sum * 100) - round($montantHt * 100)) < 1) ? 'OK' : 'ECART';
                    $st = $db->prepare('SELECT * FROM cso_devis WHERE n_offre = ?');
                    $st->execute([$n]);
                    $ex = $st->fetch();
                    $row = [
                        'date_traitement' => ma_date($d['date_traitement'] ?? null) ?? $now,
                        'n_offre' => $n,
                        'n_client' => ma_str($d['n_client'] ?? $d['numero_client'] ?? null),
                        'client' => ma_str($d['client'] ?? $d['client_nom'] ?? null),
                        'contact_client' => ma_str($d['contact_client'] ?? null),
                        'email_client' => ma_str($d['email_client'] ?? null) ?? ma_str($d['destinataire_email'] ?? null),
                        'tel_client' => ma_str($d['tel_client'] ?? null),
                        'commercial' => ma_str($d['commercial'] ?? null),
                        'contact_interne' => ma_str($d['contact_interne'] ?? null),
                        'date_offre' => ma_date(ma_str($d['date_offre'] ?? null), false),
                        'validite_offre' => ma_date(ma_str($d['validite_offre'] ?? null), false),
                        'ref_demande_client' => ma_str($d['ref_demande_client'] ?? null),
                        'montant_ht' => $montantHt,
                        'transport' => ma_float($d['transport'] ?? null),
                        'montant_ttc' => ma_float($d['montant_ttc'] ?? null),
                        'nb_lignes' => count($lignes),
                        'controle_coherence' => $controle,
                        'statut' => 'En attente',
                        'relance_1_j3' => date('Y-m-d', strtotime('+3 days')),
                        'relance_2_j7' => date('Y-m-d', strtotime('+7 days')),
                        'relance_3_j15' => date('Y-m-d', strtotime('+15 days')),
                        'relances_envoyees' => 0,
                        'fichier_source' => ma_str($d['fichier_source'] ?? null),
                        'message_id' => ma_str($d['message_id'] ?? null),
                        'destinataire_email' => ma_str($d['destinataire_email'] ?? null),
                        'copies_email' => ma_str($d['copies_email'] ?? null),
                        'empreinte' => $empreinte,
                        'updated_at' => $now,
                    ];
                    $db->beginTransaction();
                    if (!$ex) {
                        $row['version'] = 1;
                        $id = insert($db, 'cso_devis', $row);
                        $action = 'created';
                        $version = 1;
                    } elseif (($ex['empreinte'] ?? '') === $empreinte) {
                        $db->commit();
                        logEvent($db, 'cso', 'ok', 'doublon', "Devis $n reçu à nouveau sans changement", ['id' => $ex['id']]);
                        out(['ok' => true, 'action' => 'unchanged', 'id' => (int) $ex['id'], 'n_offre' => $n, 'version' => (int) $ex['version']]);
                    } else {
                        $id = (int) $ex['id'];
                        $version = (int) $ex['version'] + 1;
                        $row['version'] = $version;
                        unset($row['n_offre']);
                        update($db, 'cso_devis', $id, $row);
                        $action = 'updated';
                    }
                    $ins = $db->prepare('INSERT INTO cso_lignes(devis_id, n_offre, version, poste, reference, designation, quantite, prix_unitaire, prix_total_ht, pays_origine, code_douanier, date_traitement) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
                    foreach ($lignes as $l) {
                        $ins->execute([$id, $n, $version, ma_int($l['poste'] ?? null), ma_str($l['reference'] ?? null), ma_str($l['designation'] ?? null),
                            ma_float($l['quantite'] ?? null), ma_float($l['prix_unitaire'] ?? null), ma_float($l['prix_total_ht'] ?? null),
                            ma_str($l['pays_origine'] ?? null), ma_str($l['code_douanier'] ?? null), $row['date_traitement']]);
                    }
                    $db->commit();
                    logEvent($db, 'cso', 'ok', $action === 'created' ? 'devis_nouveau' : 'devis_revision',
                        "Devis $n - " . ($row['client'] ?? '') . ' - ' . number_format((float) $montantHt, 2, ',', ' ') . " € HT (v$version, $controle)", ['id' => $id]);
                    out(['ok' => true, 'action' => $action, 'id' => $id, 'n_offre' => $n, 'version' => $version, 'controle_coherence' => $controle, 'nb_lignes' => count($lignes)]);
                }
                if ($sub2 !== null) {
                    $id = idFrom($parts, 2);
                    if ($method === 'PATCH' || $method === 'POST') {
                        $d = $body;
                        $d['updated_at'] = $now;
                        unset($d['n_offre']);
                        update($db, 'cso_devis', $id, $d);
                        out(['ok' => true, 'devis' => getOne($db, 'cso_devis', $id)]);
                    }
                    if ($method === 'DELETE') {
                        $db->prepare('DELETE FROM cso_lignes WHERE devis_id = ?')->execute([$id]);
                        $db->prepare('DELETE FROM cso_relances WHERE devis_id = ?')->execute([$id]);
                        $db->prepare('DELETE FROM cso_devis WHERE id = ?')->execute([$id]);
                        out(['ok' => true]);
                    }
                    $dv = getOne($db, 'cso_devis', $id) ?? fail('Devis introuvable', 404);
                    $st = $db->prepare('SELECT * FROM cso_lignes WHERE devis_id = ? ORDER BY version DESC, poste, id');
                    $st->execute([$id]);
                    $dv['lignes'] = $st->fetchAll();
                    $st = $db->prepare('SELECT * FROM cso_relances WHERE devis_id = ? ORDER BY date_envoi');
                    $st->execute([$id]);
                    $dv['relances'] = $st->fetchAll();
                    out(['ok' => true, 'devis' => $dv]);
                }
                out(['ok' => true, 'rows' => listRows($db, 'cso_devis', 'date_traitement', $_GET, ['n_offre', 'client', 'contact_client', 'email_client', 'commercial', 'ref_demande_client', 'n_client'])]);
            }
            if ($sub === 'relances' && $method === 'GET') {
                // Historique des relances envoyées au client (avec la copie interne)
                $rows = $db->query("SELECT r.id, r.date_envoi, r.numero, r.n_offre, r.destinataire, r.cc, r.devis_id,
                        d.client, d.contact_client, d.commercial, d.montant_ht, d.statut, d.date_offre
                    FROM cso_relances r LEFT JOIN cso_devis d ON d.id = r.devis_id
                    ORDER BY r.date_envoi DESC, r.id DESC LIMIT 2000")->fetchAll();
                out(['ok' => true, 'rows' => $rows]);
            }
            if ($sub === 'relances' && $method === 'POST') {
                // Enregistre une relance envoyée et met à jour le devis (remplace updateRow Statut / Relances_envoyees)
                $id = (int) ($body['devis_id'] ?? 0);
                if ($id <= 0 && !empty($body['n_offre'])) {
                    $st = $db->prepare('SELECT id FROM cso_devis WHERE n_offre = ?');
                    $st->execute([(string) $body['n_offre']]);
                    $id = (int) $st->fetchColumn();
                }
                $dv = getOne($db, 'cso_devis', $id) ?? fail('Devis introuvable', 404);
                $num = (int) ($body['numero'] ?? ((int) $dv['relances_envoyees'] + 1));
                $db->prepare('INSERT INTO cso_relances(devis_id, n_offre, numero, date_envoi, destinataire, cc) VALUES (?,?,?,?,?,?)')
                    ->execute([$id, $dv['n_offre'], $num, $now, ma_str($body['destinataire'] ?? null), ma_str($body['cc'] ?? null)]);
                update($db, 'cso_devis', $id, ['statut' => "Relance $num", 'relances_envoyees' => $num, 'updated_at' => $now]);
                logEvent($db, 'cso', 'ok', "relance_$num", 'Devis ' . $dv['n_offre'] . ' - ' . ($dv['client'] ?? '') . ' -> ' . ($body['destinataire'] ?? ''), ['id' => $id]);
                out(['ok' => true, 'devis_id' => $id, 'statut' => "Relance $num", 'relances_envoyees' => $num]);
            }
            if ($sub === 'reponse' && $method === 'POST') {
                // Réponse d'un client à un devis ou à une relance, classée par l'agent IA du scénario.
                // Rattachement : en-tête In-Reply-To / References (Message-ID du mail d'origine),
                // à défaut le numéro d'offre trouvé dans l'objet.
                $sujet = ma_str($body['sujet'] ?? null) ?? '';
                $refs = trim((string) ($body['in_reply_to'] ?? '') . ' ' . (string) ($body['references'] ?? ''));
                $classement = strtolower(ma_str($body['classement'] ?? null) ?? 'autre');
                $texte = ma_str($body['texte'] ?? $body['message'] ?? null);
                $de = ma_str($body['from_email'] ?? null);
                // Les mails partant de MultiAir (offres envoyées par les commerciaux, transferts
                // internes) portent souvent « RE: » : ce ne sont pas des réponses de clients.
                if (ma_est_interne($de, ma_domaines_internes($db))) {
                    out(['ok' => true, 'ignore' => 'expediteur_interne', 'from_email' => $de]);
                }
                $devis = null;
                if ($refs !== '') {
                    foreach ($db->query("SELECT * FROM cso_devis WHERE message_id IS NOT NULL AND message_id != ''
                        ORDER BY id DESC") as $d) {
                        if (str_contains($refs, trim((string) $d['message_id'], '<> '))) {
                            $devis = $d;
                            break;
                        }
                    }
                }
                if (!$devis && preg_match_all('/\b(\d{8,10})\b/', $sujet, $m)) {
                    $st = $db->prepare('SELECT * FROM cso_devis WHERE n_offre = ? ORDER BY id DESC LIMIT 1');
                    foreach ($m[1] as $n) {
                        $st->execute([$n]);
                        if ($row = $st->fetch()) {
                            $devis = $row;
                            break;
                        }
                    }
                }
                if (!$devis) {
                    logEvent($db, 'cso', 'info', 'reponse_non_rattachee',
                        ($de ?? '') . ' - ' . $sujet . ' : aucun devis correspondant',
                        ['classement' => $classement, 'texte' => $texte]);
                    out(['ok' => true, 'trouve' => false]);
                }
                // Un statut déjà tranché à la main n'est pas écrasé ; on ajoute seulement la réponse.
                $fige = in_array($devis['statut'], ['Gagne', 'Perdu', 'Sans suite'], true);
                $nouveau = ['commande' => 'Gagne', 'refus' => 'Perdu'][$classement] ?? 'Reponse recue';
                if ($classement === 'sans_objet') {
                    $nouveau = null;
                }
                // Nom des pièces jointes du mail client (bon de commande…), si le scénario
                // les transmet. Le fichier lui-même reste dans la boîte : le commercial le
                // reçoit en direct, le tableau de bord se contente d'en garder la trace.
                $pj = $body['pieces_jointes'] ?? $body['piece_jointe'] ?? null;
                $pj = implode(', ', array_filter(array_map('trim',
                    is_array($pj) ? $pj : explode(',', (string) $pj))));
                $maj = ['updated_at' => $now];
                $maj['reponse_client'] = trim(((string) ($devis['reponse_client'] ?? '')) . "\n\n"
                    . '[' . $now . ' — ' . ($de ?? '') . ' — ' . $classement . ']'
                    . ($pj !== '' ? "\n" . 'Pièce(s) jointe(s) : ' . $pj : '')
                    . "\n" . (string) $texte);
                if ($nouveau !== null && !$fige) {
                    $maj['statut'] = $nouveau;
                }
                update($db, 'cso_devis', (int) $devis['id'], $maj);
                logEvent($db, 'cso', 'ok', $classement === 'commande' ? 'commande_recue' : 'reponse_client',
                    'Devis ' . $devis['n_offre'] . ' - ' . ($devis['client'] ?? '') . ' : ' . $classement
                        . ($pj !== '' ? ' (' . $pj . ')' : '')
                        . ($maj['statut'] ?? null ? ' -> ' . $maj['statut'] : ($fige ? ' (statut conservé)' : ' (statut inchangé)')),
                    ['id' => $devis['id'], 'de' => $de, 'pieces_jointes' => $pj]);
                out(['ok' => true, 'trouve' => true, 'devis_id' => (int) $devis['id'], 'n_offre' => $devis['n_offre'],
                    'classement' => $classement, 'statut' => $maj['statut'] ?? $devis['statut'], 'statut_fige' => $fige,
                    'client' => $devis['client'], 'commercial' => $devis['commercial'], 'pieces_jointes' => $pj]);
            }
            if ($sub === 'lignes') {
                out(['ok' => true, 'rows' => listRows($db, 'cso_lignes', 'date_traitement', $_GET, ['reference', 'designation', 'n_offre'])]);
            }
            fail('Route cso inconnue', 404);

        // ============================================================ Prime CEE
        case 'cee':
            if ($sub === 'leads') {
                if ($sub2 === 'find') {
                    // Remplace filterRows Leads WCF (dernier lead pour ce numéro) + comptage des simulations
                    $tel = ma_tel((string) ($_GET['tel'] ?? ''));
                    $st = $db->prepare('SELECT * FROM cee_leads WHERE telephone_intl = ? ORDER BY date DESC, id DESC LIMIT 1');
                    $st->execute([$tel]);
                    $r = $st->fetch();
                    $st = $db->prepare('SELECT COUNT(*) FROM cee_leads WHERE telephone_intl = ?');
                    $st->execute([$tel]);
                    $nb = (int) $st->fetchColumn();
                    out(['ok' => true, 'trouve' => (bool) $r, 'lead' => $r ?: null, 'nb_simulations' => $nb,
                        'date' => $r['date'] ?? null, 'statut' => $r['statut'] ?? null]);
                }
                if ($method === 'POST' && $sub2 === null) {
                    $d = $body;
                    $d['telephone_intl'] = ma_tel((string) ($d['telephone_intl'] ?? $d['Telephone_intl'] ?? $d['telephone_brut'] ?? $d['Telephone_brut'] ?? ''));
                    // Accepte les clés du formulaire (Prenom, Nom, ...) telles quelles
                    foreach (['Prenom' => 'prenom', 'Nom' => 'nom', 'Societe' => 'societe', 'Email' => 'email', 'Telephone_brut' => 'telephone_brut',
                        'Message_initial' => 'message_initial', 'Profil' => 'profil', 'Page_url' => 'page_url', 'Eco_an' => 'eco_an', 'Eco_5ans' => 'eco_5ans',
                        'CEE_min' => 'cee_min', 'CEE_max' => 'cee_max', 'ROI_avec_CEE' => 'roi_avec_cee', 'Regime' => 'regime', 'Usage' => 'usage',
                        'Nb_compresseurs' => 'nb_compresseurs', 'Solutions' => 'solutions', 'CO2_tonnes' => 'co2_tonnes', 'Nb_simulations' => 'nb_simulations'] as $src => $dst) {
                        if (isset($d[$src]) && !isset($d[$dst])) {
                            $d[$dst] = $d[$src];
                        }
                    }
                    foreach (['eco_an', 'eco_5ans', 'cee_min', 'cee_max', 'co2_tonnes'] as $c) {
                        $d[$c] = ma_float($d[$c] ?? null);
                    }
                    $d['nb_simulations'] = ma_int($d['nb_simulations'] ?? null);
                    $d['date'] = ma_date($d['date'] ?? null) ?? $now;
                    $d['statut'] = ma_str($d['statut'] ?? null) ?? (!empty($d['telephone_brut']) ? 'WhatsApp accueil envoye' : 'Sans tel - relance email manuelle');
                    $id = insert($db, 'cee_leads', $d);
                    logEvent($db, 'cee', 'ok', 'lead', ($d['prenom'] ?? '') . ' ' . ($d['nom'] ?? '') . ' - ' . ($d['societe'] ?? '') . ' [' . $d['statut'] . ']', ['id' => $id]);
                    out(['ok' => true, 'id' => $id, 'telephone_intl' => $d['telephone_intl'], 'statut' => $d['statut']]);
                }
                if ($sub2 !== null) {
                    $id = idFrom($parts, 2);
                    if ($method === 'PATCH' || $method === 'POST') {
                        update($db, 'cee_leads', $id, $body);
                        out(['ok' => true, 'lead' => getOne($db, 'cee_leads', $id)]);
                    }
                    if ($method === 'DELETE') {
                        $db->prepare('DELETE FROM cee_leads WHERE id = ?')->execute([$id]);
                        out(['ok' => true]);
                    }
                    $l = getOne($db, 'cee_leads', $id) ?? fail('Lead introuvable', 404);
                    $st = $db->prepare('SELECT * FROM cee_conversations WHERE telephone = ? ORDER BY date, id');
                    $st->execute([$l['telephone_intl']]);
                    $l['conversations'] = $st->fetchAll();
                    $st = $db->prepare('SELECT * FROM cee_actions WHERE telephone = ? ORDER BY date, id');
                    $st->execute([$l['telephone_intl']]);
                    $l['actions'] = $st->fetchAll();
                    out(['ok' => true, 'lead' => $l]);
                }
                out(['ok' => true, 'rows' => listRows($db, 'cee_leads', 'date', $_GET, ['prenom', 'nom', 'societe', 'email', 'telephone_intl', 'message_initial'])]);
            }
            if ($sub === 'conversations') {
                if ($method === 'POST') {
                    $tel = ma_tel((string) ($body['telephone'] ?? $body['from'] ?? ''));
                    $st = $db->prepare('SELECT id FROM cee_leads WHERE telephone_intl = ? ORDER BY date DESC LIMIT 1');
                    $st->execute([$tel]);
                    $leadId = (int) $st->fetchColumn() ?: null;
                    $d = [
                        'lead_id' => $leadId, 'telephone' => $tel, 'date' => ma_date($body['date'] ?? null) ?? $now,
                        'message' => ma_str($body['message'] ?? null), 'reponse' => ma_str($body['reponse'] ?? $body['reply'] ?? null),
                        'profil' => ma_str($body['profil'] ?? null), 'infos' => ma_str($body['infos'] ?? null), 'qualifie' => ma_str($body['qualifie'] ?? null),
                        'projet' => ma_str($body['projet'] ?? null), 'urgence' => ma_str($body['urgence'] ?? null), 'decideur' => ma_str($body['decideur'] ?? null),
                        'action' => ma_str($body['action'] ?? null),
                    ];
                    $id = insert($db, 'cee_conversations', $d);
                    if ($leadId && ma_bool($d['qualifie'] ?? false)) {
                        $db->prepare("UPDATE cee_leads SET suivi = CASE WHEN suivi = 'nouveau' THEN 'qualifie' ELSE suivi END, profil = COALESCE(?, profil) WHERE id = ?")->execute([$d['profil'], $leadId]);
                    }
                    out(['ok' => true, 'id' => $id, 'lead_id' => $leadId]);
                }
                out(['ok' => true, 'rows' => listRows($db, 'cee_conversations', 'date', $_GET, ['message', 'reponse', 'telephone', 'infos'])]);
            }
            if ($sub === 'actions') {
                if ($method === 'POST' && $sub2 === null) {
                    $tel = ma_tel((string) ($body['telephone'] ?? $body['from'] ?? ''));
                    $st = $db->prepare('SELECT id, societe FROM cee_leads WHERE telephone_intl = ? ORDER BY date DESC LIMIT 1');
                    $st->execute([$tel]);
                    $lead = $st->fetch() ?: null;
                    $d = [
                        'lead_id' => $lead['id'] ?? null, 'date' => ma_date($body['date'] ?? null) ?? $now,
                        'type_profil' => strtoupper(ma_str($body['type_profil'] ?? $body['profil'] ?? null) ?? ''),
                        'societe' => ma_str($body['societe'] ?? null) ?? ($lead['societe'] ?? null), 'telephone' => $tel,
                        'detail' => ma_str($body['detail'] ?? null), 'projet' => ma_str($body['projet'] ?? null), 'urgence' => ma_str($body['urgence'] ?? null),
                        'decideur' => ma_str($body['decideur'] ?? null), 'infos' => ma_str($body['infos'] ?? null), 'action' => ma_str($body['action'] ?? null),
                    ];
                    if (!$d['detail']) {
                        $d['detail'] = trim(implode(' | ', array_filter([$d['projet'], $d['urgence'] ? 'urgence: ' . $d['urgence'] : null, $d['decideur'] ? 'decideur: ' . $d['decideur'] : null, $d['infos']])));
                    }
                    $id = insert($db, 'cee_actions', $d);
                    logEvent($db, 'cee', 'ok', 'action', $d['type_profil'] . ' - ' . ($d['societe'] ?? '') . ' : ' . ($d['action'] ?? ''), ['id' => $id]);
                    out(['ok' => true, 'id' => $id]);
                }
                if ($sub2 !== null) {
                    $id = idFrom($parts, 2);
                    if ($method === 'PATCH' || $method === 'POST') {
                        $d = $body;
                        if (isset($d['fait'])) {
                            $d['fait'] = ma_bool($d['fait']) ? 1 : 0;
                            $d['fait_at'] = $d['fait'] ? $now : null;
                        }
                        update($db, 'cee_actions', $id, $d);
                        out(['ok' => true, 'action' => getOne($db, 'cee_actions', $id)]);
                    }
                    if ($method === 'DELETE') {
                        $db->prepare('DELETE FROM cee_actions WHERE id = ?')->execute([$id]);
                        out(['ok' => true]);
                    }
                }
                out(['ok' => true, 'rows' => listRows($db, 'cee_actions', 'date', $_GET, ['societe', 'telephone', 'detail', 'action'])]);
            }
            fail('Route cee inconnue', 404);

        case 'routage':
            $scenario = (string) ($_GET['scenario'] ?? $body['scenario'] ?? '');
            if (!in_array($scenario, ['chatbot', 'repondeur', 'adv'], true)) {
                fail('scenario requis (chatbot | repondeur | adv)');
            }
            routageRoutes($db, $scenario, $sub, $method, $body);

        // ============================================================ Statistiques
        case 'stats':
            require __DIR__ . '/stats.php';
            out(['ok' => true] + ma_stats($db, $sub ?? 'overview', $_GET));

        // ============================================================ Import en masse (page)
        case 'import':
            if ($method !== 'POST') {
                fail('POST attendu');
            }
            $table = (string) ($body['table'] ?? '');
            $rows = $body['rows'] ?? [];
            $st = $db->prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?");
            $st->execute([$table]);
            if (!preg_match('/^[a-z_]+$/', $table) || !$st->fetchColumn()) {
                fail("Table inconnue : $table");
            }
            $n = 0;
            $db->beginTransaction();
            foreach ($rows as $r) {
                if (is_array($r)) {
                    insert($db, $table, $r);
                    $n++;
                }
            }
            $db->commit();
            out(['ok' => true, 'table' => $table, 'inseres' => $n]);

        // ============================================================ Export CSV
        case 'export':
            $table = (string) ($sub ?? '');
            $st = $db->prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?");
            $st->execute([$table]);
            if (!$st->fetchColumn()) {
                fail("Table inconnue : $table", 404);
            }
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $table . '_' . date('Y-m-d') . '.csv"');
            echo "\xEF\xBB\xBF";
            $fp = fopen('php://output', 'w');
            $first = true;
            foreach ($db->query("SELECT * FROM $table ORDER BY id DESC") as $row) {
                if ($first) {
                    fputcsv($fp, array_keys($row), ';');
                    $first = false;
                }
                fputcsv($fp, $row, ';');
            }
            exit;

        default:
            fail("Route inconnue : $route", 404);
    }
} catch (PDOException $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    $msg = $e->getMessage();
    if (str_contains($msg, 'no such table') || str_contains($msg, 'no such column')) {
        fail("Base de données pas à jour (version du code : " . MA_VERSION . "). Déposez le dernier "
            . "correctif MULTIAIR en écrasant les fichiers, puis rechargez la page. Détail : " . $msg, 500);
    }
    fail('Erreur base de données : ' . $msg, 500);
} catch (Throwable $e) {
    fail('Erreur : ' . $e->getMessage(), 500);
}
